const { MessageType } = require('@adiwajshing/baileys')
let fetch = require('node-fetch')
let fs = require('fs')
let handler = async (m, { conn, text }) => {
let logo = fs.readFileSync(`./src/img2.png`)
  let ext= `
*───────[ BIODATA OWNER 1 ]───────*
*💌 Nama* : Dedy Tobing
*🎨 Umur* : 19
*🧮 Kelas* : 20T01
*📈 Status* : Mahasiswa

*───────[ SOSIAL MEDIA ]───────*
*📷 instagran* : @dedytbng
*🇫  Facebook* : デディ
*🏮 Chanel Youtube* : Dedy Tobing

*───────[ BIODATA OWNER 2 ]───────*
*💌 Nama* : Kevin Sihombing
*🎨 Umur* : 19
*🧮 Kelas* : 22T01
*📈 Status* : Mahasiswa

*───────[ SOSIAL MEDIA ]───────*
*📷 instagran* : @kevin_sihombing05
*🇫  Facebook* : Kevin Sihombing
*🏮 Chanel Youtube* : Kevin Official

*───────[ BIODATA OWNER 3 ]───────*
*💌 Nama* : Robert Situmorang
*🎨 Umur* : 19
*🧮 Kelas* : NONE
*📈 Status* : Siswa Binaan Magang

*───────[ SOSIAL MEDIA ]───────*
*📷 instagran* : NONE
*🇫  Facebook* : Robet
*🏮 Chanel Youtube* : NONE
`
let name = await conn.getName(m.sender)

let fkon = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: '16504228206@s.whatsapp.net' } : {}) }, message: { contactMessage: { displayName: `${name}`, vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}}

  sumberImg = fs.readFileSync(`./src/img1.png`)
  image = (await conn.prepareMessage('0@s.whatsapp.net', sumberImg, MessageType.image, { thumbnail: Buffer.alloc(0) })).message.imageMessage
  res = await conn.prepareMessageFromContent(m.chat, {
    "productMessage": {
      "product": {
        "productImage": image,
        "productId": "4938174216214248",
        "title": "───────[ OWNER ]───────",
        "description": '\n\n' + ext,
        "retailerId": "Itu Owner ku ya ^~^",
        "url": '',
        "descriptionCount": "999999999",
        "productImageCount": "1",
      },
      "businessOwnerJid": "6287792151648@s.whatsapp.net",
      "contextInfo": {
        "forwardingScore": 9999,
        "isForwarded": false
      }
    }
  },
    { quoted: fkon })
  conn.relayWAMessage(res)

}
handler.help = ['ownerinfo']
handler.tags = ['info']
handler.command = /^(ownerinfo)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

let wm = global.botwm
