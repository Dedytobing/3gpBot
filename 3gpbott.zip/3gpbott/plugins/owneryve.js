let handler = function (m) {
	this.sendContact(m.chat, '6282268736623', 'Owner 3gpBot :)', m.chat, '6283897873987', 'Owner 3gpBot :)',m.chat, '6281298733743', 'Owner 3gpBot :)',)
}

handler.customPrefix = ['🍭Owner 3gp'] 
handler.command = new RegExp

module.exports = handler